// Demo products. Later, these can come from a database or API.
export const products = [
  {
    id: 1,
    name: "Everyday Tote Bag",
    category: "Fashion",
    price: 899,
    oldPrice: 1199,
    emoji: "👜",
    color: "#e9dfd0",
    tag: "BESTSELLER",
    rating: "4.8",
    description:
      "Your easy, everyday carryall. A roomy silhouette with a clean, versatile look for errands and weekend plans."
  },
  {
    id: 2,
    name: "Minimal Sneakers",
    category: "Fashion",
    price: 1899,
    oldPrice: 2299,
    emoji: "👟",
    color: "#e4e8df",
    tag: "POPULAR",
    rating: "4.7",
    description:
      "Comfort-first sneakers with a minimal profile, made to pair effortlessly with your daily wardrobe."
  },
  {
    id: 3,
    name: "Studio Headphones",
    category: "Electronics",
    price: 2499,
    oldPrice: 2999,
    emoji: "🎧",
    color: "#e5e2ef",
    tag: "TRENDING",
    rating: "4.9",
    description:
      "A sleek everyday design for music, calls and focus time."
  },
  {
    id: 4,
    name: "Smart Watch",
    category: "Electronics",
    price: 3299,
    oldPrice: 3999,
    emoji: "⌚",
    color: "#dfe9ed",
    tag: "NEW",
    rating: "4.6",
    description:
      "A modern wrist essential with a polished look for your everyday routine."
  },
  {
    id: 5,
    name: "Classic Sunglasses",
    category: "Accessories",
    price: 699,
    oldPrice: 999,
    emoji: "🕶️",
    color: "#f0e4d6",
    tag: "SAVE 30%",
    rating: "4.5",
    description:
      "A timeless accessory that completes casual and dressed-up looks."
  },
  {
    id: 6,
    name: "Everyday Watch",
    category: "Accessories",
    price: 1599,
    oldPrice: 1999,
    emoji: "⌚",
    color: "#eee5d8",
    tag: "FAVOURITE",
    rating: "4.7",
    description:
      "A refined, versatile watch with a clean face for weekdays and weekends."
  },
  {
    id: 7,
    name: "Ceramic Table Vase",
    category: "Home",
    price: 799,
    oldPrice: 1099,
    emoji: "🏺",
    color: "#e7e2d8",
    tag: "DESIGN PICK",
    rating: "4.8",
    description:
      "A sculptural accent for shelves, desks and dining tables."
  },
  {
    id: 8,
    name: "Soft Throw Cushion",
    category: "Home",
    price: 599,
    oldPrice: 799,
    emoji: "🛋️",
    color: "#e0e9df",
    tag: "COZY PICK",
    rating: "4.6",
    description:
      "A soft, versatile home accent for your favourite corner."
  }
];

export const categories = [
  { name: "Fashion", emoji: "🧥", subtitle: "Style essentials" },
  { name: "Electronics", emoji: "🎧", subtitle: "Everyday tech" },
  { name: "Accessories", emoji: "⌚", subtitle: "Finishing touches" },
  { name: "Home", emoji: "🏡", subtitle: "Make it yours" }
];

export const formatPrice = (price) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0
  }).format(price);