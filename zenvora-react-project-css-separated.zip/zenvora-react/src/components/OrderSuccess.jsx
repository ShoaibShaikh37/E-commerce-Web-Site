import { formatPrice } from "../data/products";
import "./OrderSuccess.css";

export default function OrderSuccess({ order, onContinueShopping }) {
  if (!order) return null;

  return (
    <main className="container page-content">
      <section className="success-card">
        <div className="success-check">✓</div>
        <span className="eyebrow">ORDER CONFIRMED</span>
        <h1>Thank you for your order!</h1>
        <p className="muted">Your Zenvora order has been placed successfully in this demo.</p>
        <div className="order-number">Order ID: {order.id}</div>
        <p className="success-details">
          Order for <strong>{order.name}</strong><br />
          Total: <strong>{formatPrice(order.total)}</strong><br />
          Payment: <strong>{order.payment}</strong>
        </p>
        <button className="primary-button" onClick={onContinueShopping}>Continue Shopping ↗</button>
      </section>
    </main>
  );
}