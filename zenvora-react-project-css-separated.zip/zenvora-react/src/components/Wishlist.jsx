import { formatPrice } from "../data/products";
import "./Wishlist.css";

export default function Wishlist({ products, onBack, onOpenProduct, onToggleWishlist, onAddToCart }) {
  return (
    <main className="container page-content">
      <button className="back-button" onClick={onBack}>← Back to Products</button>
      <h1>Your Wishlist ♡</h1>

      {products.length === 0 ? (
        <div className="empty-state">
          <div className="empty-emoji">♡</div>
          <h2>Your wishlist is waiting</h2>
          <p>Tap a heart on a product to save it here.</p>
          <button className="primary-button" onClick={onBack}>Explore Products</button>
        </div>
      ) : (
        <div className="product-grid">
          {products.map((product) => (
            <article className="product-card" key={product.id}>
              <button className="product-image" style={{ backgroundColor: product.color }} onClick={() => onOpenProduct(product)}>
                <span className="product-emoji">{product.emoji}</span>
              </button>
              <button className="wishlist-heart" onClick={() => onToggleWishlist(product.id)}>♥</button>
              <div className="product-info">
                <button className="product-name" onClick={() => onOpenProduct(product)}>{product.name}</button>
                <div className="price-line"><strong>{formatPrice(product.price)}</strong></div>
                <button className="add-button" onClick={() => onAddToCart(product.id)}>Add to Cart +</button>
              </div>
            </article>
          ))}
        </div>
      )}
    </main>
  );
}