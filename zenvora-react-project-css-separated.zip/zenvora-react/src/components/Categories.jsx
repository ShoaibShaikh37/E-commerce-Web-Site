import { categories } from "../data/products";
import "./Categories.css";

export default function Categories({ selectedCategory, onSelectCategory }) {
  return (
    <section className="section-block" id="categories">
      <div className="section-heading">
        <div>
          <span className="eyebrow">BROWSE YOUR WAY</span>
          <h2>Shop by category</h2>
          <p className="muted">A little something for every kind of day.</p>
        </div>
        <button className="outline-button" onClick={() => onSelectCategory("")}>
          View all
        </button>
      </div>

      <div className="category-grid">
        {categories.map((category) => (
          <button
            key={category.name}
            className={`category-card ${
              selectedCategory === category.name ? "selected" : ""
            }`}
            onClick={() => onSelectCategory(category.name)}
          >
            <span className="category-icon">{category.emoji}</span>
            <span>
              <strong>{category.name === "Home" ? "Home & Living" : category.name}</strong>
              <small>{category.subtitle}</small>
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}