import { formatPrice } from "../data/products";
import "./Checkout.css";

export default function Checkout({ items, subtotal, onBack, onPlaceOrder }) {
  const shipping = subtotal >= 1999 ? 0 : 99;
  const total = subtotal + shipping;

  function handleSubmit(event) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    onPlaceOrder({
      name: formData.get("fullName"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      address: formData.get("address"),
      city: formData.get("city"),
      state: formData.get("state"),
      pincode: formData.get("pincode"),
      payment: formData.get("payment"),
      total
    });
  }

  return (
    <main className="container page-content">
      <button className="back-button" onClick={onBack}>← Back</button>
      <div className="section-heading checkout-title">
        <div><span className="eyebrow">ALMOST YOURS</span><h1>Checkout</h1><p className="muted">Add your details to place your order.</p></div>
      </div>

      <form className="checkout-layout" onSubmit={handleSubmit}>
        <div className="panel">
          <h2>Customer details</h2>
          <div className="form-grid">
            <label className="form-field">Full name *
              <input name="fullName" required autoComplete="name" placeholder="Your full name" />
            </label>
            <label className="form-field">Phone number *
              <input name="phone" type="tel" required pattern="[0-9 +()-]{10,16}" autoComplete="tel" placeholder="Your phone number" />
            </label>
            <label className="form-field full-span">Email address
              <input name="email" type="email" autoComplete="email" placeholder="you@example.com" />
            </label>
            <label className="form-field full-span">Full address *
              <textarea name="address" required autoComplete="street-address" placeholder="House no., street, area" />
            </label>
            <label className="form-field">City *
              <input name="city" required autoComplete="address-level2" placeholder="Your city" />
            </label>
            <label className="form-field">State *
              <input name="state" required autoComplete="address-level1" placeholder="Your state" />
            </label>
            <label className="form-field">PIN code *
              <input name="pincode" required pattern="[0-9]{6}" inputMode="numeric" autoComplete="postal-code" placeholder="6-digit PIN code" />
            </label>
          </div>

          <h2 className="payment-heading">Payment method</h2>
          <div className="payment-options">
            <label className="payment-option"><input type="radio" name="payment" value="Cash on Delivery" defaultChecked /> <span>💵 <strong>Cash on Delivery</strong><small>Pay when your order arrives</small></span></label>
            <label className="payment-option"><input type="radio" name="payment" value="UPI (demo)" /> <span>📱 <strong>UPI (demo)</strong><small>No payment is collected in this demo</small></span></label>
            <label className="payment-option"><input type="radio" name="payment" value="Card (demo)" /> <span>💳 <strong>Credit / Debit Card (demo)</strong><small>Never enter card details in this demo</small></span></label>
          </div>
          <p className="muted fine-print">This is a demo checkout. Real online payments need a secure payment gateway and backend.</p>
          <button className="primary-button full-width" type="submit">Place Order · {formatPrice(total)}</button>
        </div>

        <aside className="panel">
          <h2>Order summary</h2>
          {items.map(({ product, quantity }) => (
            <div className="summary-product" key={product.id}>
              <div className="mini-product" style={{ backgroundColor: product.color }}>{product.emoji}</div>
              <div className="summary-product-copy"><strong>{product.name}</strong><small>Qty: {quantity}</small></div>
              <strong>{formatPrice(product.price * quantity)}</strong>
            </div>
          ))}
          <div className="summary-row"><span>Subtotal</span><strong>{formatPrice(subtotal)}</strong></div>
          <div className="summary-row"><span>Shipping</span><strong>{shipping ? formatPrice(shipping) : "Free"}</strong></div>
          <div className="summary-row total-row"><span>Total</span><strong>{formatPrice(total)}</strong></div>
        </aside>
      </form>
    </main>
  );
}