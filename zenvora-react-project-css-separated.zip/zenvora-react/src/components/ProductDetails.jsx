import { formatPrice } from "../data/products";
import "./ProductDetails.css";

export default function ProductDetails({
  product,
  quantity,
  onQuantityChange,
  isWishlisted,
  onBack,
  onAddToCart,
  onBuyNow,
  onToggleWishlist
}) {
  if (!product) return null;

  return (
    <main className="container page-content">
      <button className="back-button" onClick={onBack}>← Back to Products</button>

      <div className="detail-layout">
        <div className="detail-image" style={{ backgroundColor: product.color }}>
          {product.emoji}
        </div>

        <div className="detail-copy">
          <span className="eyebrow">{product.category} · {product.tag}</span>
          <h1>{product.name}</h1>
          <p className="rating">★ {product.rating} / 5 · Customer favourite</p>
          <div className="detail-price">
            <strong>{formatPrice(product.price)}</strong>
            <del>{formatPrice(product.oldPrice)}</del>
          </div>
          <p className="detail-description">{product.description}</p>
          <ul className="benefit-list">
            <li>✓ Quality-picked everyday essential</li>
            <li>✓ Easy styling and versatile use</li>
            <li>✓ Demo checkout experience</li>
          </ul>

          <div className="quantity-control">
            <strong>Quantity</strong>
            <button onClick={() => onQuantityChange(-1)} aria-label="Decrease quantity">−</button>
            <span>{quantity}</span>
            <button onClick={() => onQuantityChange(1)} aria-label="Increase quantity">+</button>
          </div>

          <div className="detail-actions">
            <button className="primary-button" onClick={() => onBuyNow(product.id)}>
              Buy Now · {formatPrice(product.price * quantity)}
            </button>
            <button className="outline-button" onClick={() => onAddToCart(product.id, quantity)}>
              Add to Cart
            </button>
            <button className="outline-button" onClick={() => onToggleWishlist(product.id)}>
              {isWishlisted ? "♥ Wishlisted" : "♡ Wishlist"}
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}