import { formatPrice } from "../data/products";
import "./ProductList.css";

export default function ProductList({
  products,
  selectedCategory,
  searchTerm,
  wishlist,
  onOpenProduct,
  onToggleWishlist,
  onAddToCart
}) {
  const heading = searchTerm
    ? `Search results for “${searchTerm}”`
    : selectedCategory
      ? selectedCategory === "Home" ? "Home & Living" : selectedCategory
      : "Popular right now";

  return (
    <section className="section-block" id="products">
      <div className="section-heading">
        <div>
          <span className="eyebrow">MADE FOR YOUR EVERYDAY</span>
          <h2>{heading}</h2>
          <p className="muted">Customer favourites, all in one place.</p>
        </div>
        <span className="muted">{products.length} products</span>
      </div>

      {products.length === 0 ? (
        <div className="empty-state">
          <h3>No products found</h3>
          <p>Try a different search or category.</p>
        </div>
      ) : (
        <div className="product-grid">
          {products.map((product) => (
            <article className="product-card" key={product.id}>
              <button
                className="product-image"
                style={{ backgroundColor: product.color }}
                onClick={() => onOpenProduct(product)}
                aria-label={`View ${product.name}`}
              >
                <span className="product-tag">{product.tag}</span>
                <span className="product-emoji">{product.emoji}</span>
              </button>

              <button
                className="wishlist-heart"
                onClick={() => onToggleWishlist(product.id)}
                aria-label={wishlist.includes(product.id) ? "Remove from wishlist" : "Add to wishlist"}
              >
                {wishlist.includes(product.id) ? "♥" : "♡"}
              </button>

              <div className="product-info">
                <button className="product-name" onClick={() => onOpenProduct(product)}>
                  {product.name}
                </button>
                <p className="rating">★ {product.rating} <span>· {product.category}</span></p>
                <div className="price-line">
                  <strong>{formatPrice(product.price)}</strong>
                  <del>{formatPrice(product.oldPrice)}</del>
                </div>
                <button className="add-button" onClick={() => onAddToCart(product.id)}>
                  Add to Cart +
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}