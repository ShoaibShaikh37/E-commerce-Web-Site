import "./Hero.css";
export default function Hero({ onShopNow }) {
  return (
    <section className="hero-section">
      <div className="hero-card">
        <div className="hero-copy">
          <span className="eyebrow">THE EVERYDAY EDIT · 2026</span>
          <h1>Find your<br />next favourite.</h1>
          <p>
            Thoughtfully picked essentials for your style, your space,
            and everything in between.
          </p>
          <button className="primary-button" onClick={onShopNow}>
            Shop Now <span aria-hidden="true">↗</span>
          </button>
        </div>
        <div className="hero-art" aria-label="Zenvora decorative brand artwork">
          <span>Z</span>
        </div>
      </div>
    </section>
  );
}