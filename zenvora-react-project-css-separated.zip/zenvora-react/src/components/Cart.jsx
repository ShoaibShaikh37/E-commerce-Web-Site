import { formatPrice } from "../data/products";
import "./Cart.css";

export default function Cart({ items, subtotal, onBack, onChangeQuantity, onRemove, onCheckout }) {
  const shipping = subtotal >= 1999 || subtotal === 0 ? 0 : 99;

  return (
    <main className="container page-content">
      <button className="back-button" onClick={onBack}>← Continue Shopping</button>
      <h1>Your Cart</h1>

      {items.length === 0 ? (
        <div className="empty-state">
          <div className="empty-emoji">🛍️</div>
          <h2>Your cart is empty</h2>
          <p>Add something you love to get started.</p>
          <button className="primary-button" onClick={onBack}>Explore Products</button>
        </div>
      ) : (
        <div className="checkout-layout">
          <div className="panel">
            {items.map(({ product, quantity }) => (
              <div className="cart-row" key={product.id}>
                <div className="mini-product" style={{ backgroundColor: product.color }}>
                  {product.emoji}
                </div>
                <div className="cart-product-copy">
                  <strong>{product.name}</strong>
                  <small>{formatPrice(product.price)} each</small>
                  <div className="quantity-control compact">
                    <button onClick={() => onChangeQuantity(product.id, -1)}>−</button>
                    <span>{quantity}</span>
                    <button onClick={() => onChangeQuantity(product.id, 1)}>+</button>
                  </div>
                </div>
                <strong>{formatPrice(product.price * quantity)}</strong>
                <button className="remove-button" onClick={() => onRemove(product.id)} aria-label="Remove item">×</button>
              </div>
            ))}
          </div>

          <aside className="panel">
            <h2>Order summary</h2>
            <div className="summary-row"><span>Subtotal</span><strong>{formatPrice(subtotal)}</strong></div>
            <div className="summary-row"><span>Shipping</span><strong>{shipping ? formatPrice(shipping) : "Free"}</strong></div>
            <div className="summary-row total-row"><span>Total</span><strong>{formatPrice(subtotal + shipping)}</strong></div>
            <button className="primary-button full-width" onClick={onCheckout}>Proceed to Checkout →</button>
          </aside>
        </div>
      )}
    </main>
  );
}