import "./Navbar.css";
export default function Navbar({
  searchTerm,
  onSearchChange,
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onGoHome
}) {
  return (
    <header className="site-header">
      <div className="topline">COMPLIMENTARY SHIPPING ON ORDERS OVER ₹1,999</div>
      <nav className="navbar container">
        <button className="brand" onClick={onGoHome} aria-label="Zenvora home">
          ZEN<span>V</span>ORA
        </button>

        <label className="search-box">
          <span aria-hidden="true">⌕</span>
          <input
            type="search"
            value={searchTerm}
            onChange={(event) => onSearchChange(event.target.value)}
            placeholder="Search products..."
            aria-label="Search products"
          />
        </label>

        <div className="nav-actions">
          <button className="nav-button" onClick={onOpenWishlist}>
            ♡ <span>Wishlist</span> <b>{wishlistCount}</b>
          </button>
          <button className="nav-button" onClick={onOpenCart}>
            ▢ <span>Cart</span> <b>{cartCount}</b>
          </button>
        </div>
      </nav>
    </header>
  );
}