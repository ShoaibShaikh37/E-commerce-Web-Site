import { useEffect, useMemo, useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Categories from "./components/Categories";
import ProductList from "./components/ProductList";
import ProductDetails from "./components/ProductDetails";
import Cart from "./components/Cart";
import Wishlist from "./components/Wishlist";
import Checkout from "./components/Checkout";
import OrderSuccess from "./components/OrderSuccess";
import { products as allProducts } from "./data/products";

const readStorage = (key, fallback) => {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch {
    return fallback;
  }
};

export default function App() {
  // STATE: information that changes while the customer uses the website.
  const [page, setPage] = useState("home");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [cart, setCart] = useState(() => readStorage("zenvora-cart", {}));
  const [wishlist, setWishlist] = useState(() => readStorage("zenvora-wishlist", []));
  const [order, setOrder] = useState(null);
  const [notice, setNotice] = useState("");

  // Save cart and wishlist in this browser so a refresh does not clear them.
  useEffect(() => {
    localStorage.setItem("zenvora-cart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem("zenvora-wishlist", JSON.stringify(wishlist));
  }, [wishlist]);

  // DERIVED DATA: calculate visible products and cart totals from state.
  const filteredProducts = useMemo(() => {
    return allProducts.filter((product) => {
      const matchesCategory =
        !selectedCategory || product.category === selectedCategory;
      const query = searchTerm.trim().toLowerCase();
      const matchesSearch =
        !query ||
        `${product.name} ${product.category} ${product.description}`
          .toLowerCase()
          .includes(query);
      return matchesCategory && matchesSearch;
    });
  }, [searchTerm, selectedCategory]);

  const cartItems = useMemo(() => {
    return Object.entries(cart)
      .map(([id, quantityInCart]) => ({
        product: allProducts.find((product) => product.id === Number(id)),
        quantity: quantityInCart
      }))
      .filter((item) => item.product && item.quantity > 0);
  }, [cart]);

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );
  const wishlistProducts = allProducts.filter((product) =>
    wishlist.includes(product.id)
  );

  // ACTIONS: functions that update state or move to another page.
  function showNotice(message) {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2200);
  }

  function goHome(scrollToProductList = false) {
    setPage("home");
    if (scrollToProductList) {
      window.setTimeout(() => {
        document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
      }, 50);
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  function openProduct(product) {
    setSelectedProduct(product);
    setQuantity(1);
    setPage("details");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function addToCart(productId, amount = 1) {
    setCart((currentCart) => ({
      ...currentCart,
      [productId]: (currentCart[productId] || 0) + amount
    }));
    showNotice("Added to cart ✓");
  }

  function changeCartQuantity(productId, change) {
    setCart((currentCart) => {
      const nextQuantity = (currentCart[productId] || 0) + change;
      const updatedCart = { ...currentCart };
      if (nextQuantity <= 0) {
        delete updatedCart[productId];
      } else {
        updatedCart[productId] = nextQuantity;
      }
      return updatedCart;
    });
  }

  function removeFromCart(productId) {
    setCart((currentCart) => {
      const updatedCart = { ...currentCart };
      delete updatedCart[productId];
      return updatedCart;
    });
  }

  function toggleWishlist(productId) {
    setWishlist((currentWishlist) =>
      currentWishlist.includes(productId)
        ? currentWishlist.filter((id) => id !== productId)
        : [...currentWishlist, productId]
    );
  }

  function buyNow(productId) {
    setCart((currentCart) => ({
      ...currentCart,
      [productId]: (currentCart[productId] || 0) + quantity
    }));
    setPage("checkout");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function placeOrder(customerDetails) {
    const newOrder = {
      ...customerDetails,
      id: `ZNV-${Math.floor(100000 + Math.random() * 900000)}`
    };
    setOrder(newOrder);
    setCart({});
    setPage("success");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function chooseCategory(category) {
    setSelectedCategory(category);
    setPage("home");
    window.setTimeout(() => {
      document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
    }, 50);
  }

  function openCheckout() {
    if (cartItems.length === 0) {
      showNotice("Your cart is empty");
      return;
    }
    setPage("checkout");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <>
      <Navbar
        searchTerm={searchTerm}
        onSearchChange={(value) => {
          setSearchTerm(value);
          setSelectedCategory("");
          setPage("home");
        }}
        cartCount={cartCount}
        wishlistCount={wishlist.length}
        onOpenCart={() => { setPage("cart"); window.scrollTo(0, 0); }}
        onOpenWishlist={() => { setPage("wishlist"); window.scrollTo(0, 0); }}
        onGoHome={() => goHome()}
      />

      {page === "home" && (
        <main className="container">
          <Hero onShopNow={goHome.bind(null, true)} />
          <Categories
            selectedCategory={selectedCategory}
            onSelectCategory={chooseCategory}
          />
          <ProductList
            products={filteredProducts}
            selectedCategory={selectedCategory}
            searchTerm={searchTerm}
            wishlist={wishlist}
            onOpenProduct={openProduct}
            onToggleWishlist={toggleWishlist}
            onAddToCart={addToCart}
          />
        </main>
      )}

      {page === "details" && selectedProduct && (
        <ProductDetails
          product={selectedProduct}
          quantity={quantity}
          onQuantityChange={(change) =>
            setQuantity((current) => Math.min(10, Math.max(1, current + change)))
          }
          isWishlisted={wishlist.includes(selectedProduct.id)}
          onBack={() => goHome(true)}
          onAddToCart={addToCart}
          onBuyNow={buyNow}
          onToggleWishlist={toggleWishlist}
        />
      )}

      {page === "cart" && (
        <Cart
          items={cartItems}
          subtotal={cartSubtotal}
          onBack={() => goHome(true)}
          onChangeQuantity={changeCartQuantity}
          onRemove={removeFromCart}
          onCheckout={openCheckout}
        />
      )}

      {page === "wishlist" && (
        <Wishlist
          products={wishlistProducts}
          onBack={() => goHome(true)}
          onOpenProduct={openProduct}
          onToggleWishlist={toggleWishlist}
          onAddToCart={addToCart}
        />
      )}

      {page === "checkout" && (
        <Checkout
          items={cartItems}
          subtotal={cartSubtotal}
          onBack={() => {
            setPage(selectedProduct ? "details" : "cart");
            window.scrollTo(0, 0);
          }}
          onPlaceOrder={placeOrder}
        />
      )}

      {page === "success" && (
        <OrderSuccess order={order} onContinueShopping={() => goHome()} />
      )}

      <footer className="site-footer">
        <div className="container footer-content">
          <div><div className="footer-brand">ZEN<span>V</span>ORA</div><p>Find your everyday favourites.</p></div>
          <p>© 2026 Zenvora. React demo storefront.</p>
        </div>
      </footer>

      {notice && <div className="toast" role="status">{notice}</div>}
    </>
  );
}