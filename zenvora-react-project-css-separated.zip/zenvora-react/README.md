# ZENVORA React Storefront

A beginner-friendly React + Vite demo store.

## Run in VS Code

1. Install Node.js (LTS).
2. Open this folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL shown in your terminal (usually http://localhost:5173).

## Project structure

```text
zenvora/
├── index.html
├── package.json
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── styles.css
    ├── data/
    │   └── products.js
    └── components/
        ├── Navbar.jsx
        ├── Hero.jsx
        ├── Categories.jsx
        ├── ProductList.jsx
        ├── ProductDetails.jsx
        ├── Cart.jsx
        ├── Wishlist.jsx
        ├── Checkout.jsx
        └── OrderSuccess.jsx
```

## Beginner guide

- `main.jsx`: starts React and loads the main App component.
- `App.jsx`: holds shared state and decides which page is visible.
- `data/products.js`: the sample product catalogue and price formatting helper.
- `components/`: reusable UI pieces, one component per file.
- `styles.css`: shared/global styles and theme variables.
- Each component has its own matching CSS file, e.g. `Navbar.jsx` + `Navbar.css`, so you can learn and edit styles one section at a time.

## Shopping flow

Home → click a product → Product Details → Add to Cart / Buy Now → Checkout form → Order Success.

Navbar can open Cart and Wishlist. Search and categories filter the products. Cart and wishlist are stored in the current browser using localStorage.

## Important demo limitation

The checkout creates a demo order only. It does not send orders to a server, collect payments, send emails, or protect customer data on a backend. UPI/card options are labels for the demo only. For production, add a backend/database and integrate a payment gateway such as Razorpay securely; never collect or store raw card data yourself.
